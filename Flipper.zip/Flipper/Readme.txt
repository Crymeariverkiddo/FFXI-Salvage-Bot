Blah blah blah:

Use at your own risk. The bot has various functions but I only updated the ID's for Salvage and the Bloody Rondo assault. Do the rest yourself and keep EliteMMO API up to date to make this work. 

The bot it is trash, expect issues. I did not write it but it has no license against sharing it or decompiling it.

I considered releasing this for awhile after a client gave it to me. I stopped my own Salvage bot because these fucks are in Salvage with 35+ characters 24/7. Not only on Asura. As a result, entry time is less than efficient. Besides AR, some of you have maybe encountered the issue of entering any of the zones yourself. 

SE didn't care about my reports but maybe they will if more of you do it. Else this bot will at least get their attention now that it's out for all. Why not get some easy Alexandrite for yourself? :)

File Requirements:

1. Run EliteMMO SystemCheck to ensure you have the necessary MSVC distribution packs and proper .net framework
2. Unblock EliteMMO dll files in window file properties if necessary
3. Place npchelper.lua into \Windower\Addons\npchelper\

Game Requirements:

1. Captain Rank
2. MNK RDM or THF with /DNC or /RDM
3. 119+ equipment
4. Sufficient imperial standing and assault points.

Fun:
List of the names of the characters botting Salvage 24/7 on Asura. Feel free to report them at either address.

https://support.na.square-enix.com/contacttop.php?id=20&la=1
https://support.eu.square-enix.com/contacttop.php?id=455&la=2

Apexavocado, Bitbit, Bitlonger, Btcit, Cvda, Ermecan, Erythe, Huitzilopochtli, Inprep, Ismfirst, Katanaes, Lampn, Laolady, Larabegins, Laylee, Myotis, Nanysa, Nijinew, Ouni, Peonys, Restoration, Schaka, Severnce, Sgav, Shiivaa, Singasung, Skism, Skyluvz, Stfast, Summerside, Tchu, Tengaxx, Thebst, Theelder, Xcza, Yooka, Zaron, Zhongqin