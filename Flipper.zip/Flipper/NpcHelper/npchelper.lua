_addon.name = 'NPC Dialog Helper'
_addon.author = 'dazusu'
_addon.commands = {'npchelper'}
_addon.version = '1.0.6.2'
packets = require('packets')
require('maths')
require('tables')
require('lists')
res = require('resources')

conf = {}
action = -1
working = false
rechest = false



windower.register_event('action', function(act)
   local p = windower.ffxi.get_player()
    if act['category'] == 4 and act['actor_id'] == p['id'] then
        windower.add_to_chat(2, ">> NPCHE CF")
    end
    if act['category'] == 8 and act['actor_id'] == p['id'] and act['param'] == 24931 then
        windower.add_to_chat(2, ">> NPCHE CS")
    end
    if act['category'] == 8 and act['actor_id'] == p['id'] and act['param'] == 28787 then
        windower.add_to_chat(2, ">> NPCHE CI")
    end
end)

windower.register_event('addon command',function(...)

    local command = {...}

    for i,v in pairs(windower.ffxi.get_mob_array()) do
        if v['name'] == windower.ffxi.get_player().name then
            conf['Player Index'] = i
        end
    end

    -- Sinister Reign - Poke Malobra (Balamor)
    if command[1] == 'srkeyitem' then
        working = true
        action = 4300
        conf['Target'] = 17908273
        conf['Target Index'] = 561
        poke(conf)
    end

    if command[1] == 'sringrid' then
        working = true
        action = 4400
        conf['Target'] = 17908275
        conf['Target Index'] = 563
        poke(conf)
    end

    if command[1] == 'tradelamp' then
        working = true
        action = 783
        local name = 'Smouldering Lamp'
        local item = res.items:with('name', windower.wc_match+{name})
        local quantity = 1
        if not item then
            error('Item %s not found.':format(name))
            return
        end
        local pool = L(windower.ffxi.get_items(0)):filter(function(t) return t.id == item.id end):sort(function(t1, t2) return t1.count > t2.count end)
        pool = pool:slice(1, math.min(pool:length(), 8))
        local available = pool:reduce(function(acc, t) return t.count + acc end, 0)
        if available < quantity then
            error('Only %u items in inventory, %u required.':format(available, quantity))
            return
        end
        local slots = (quantity / item.stack):ceil()

        local packet = packets.new('outgoing', 0x036)
        packet["Target"] = 17097342
        packet["Item Count 1"] = 1
        packet["_unknown1"] = 0
        packet["_unknown2"] = 0
        packet["Item Index 1"] = pool[1].slot
        packet["Target Index"] = 638
        packet["Number of Items"] = 1
        packets.inject(packet)
    end

    if command[1] == 'v' then
        windower.add_to_chat(2, ">> NPCHE VR " .. _addon.version)
    end

    if command[1] == 'immani' then
        conf['Target'] = 16875919
        conf['Target Index'] = 399
        working = true
        action = 701
        poke(conf)
    end

    if command[1] == 'valkemp' then
        conf['Target'] = 17199757
        conf['Target Index'] = 653
        working = true
        action = 702
        poke(conf)
    end

    if command[1] == 'getlamp' then
        local packet = packets.new('outgoing', 0x036)
        packet["Target"] = 16994397
        packet["Item Count 1"] = 1000
        packet["_unknown1"] = 0
        packet["_unknown2"] = 0
        packet["Item Index 1"] = 0
        packet["Target Index"] = 93
        packet["Number of Items"] = 1
        packets.inject(packet)
    end

    if command[1] == 'intui' then
        conf['Target'] = 17199757
        conf['Target Index'] = 653
        working = true
        action = 703
        poke(conf)
    end

    if command[1] == 'enterreisenjima' then
        conf['Target'] = 17195618
        conf['Target Index'] = 610
        working = true
        action = 666
        poke(conf)
    end

    if command[1] == 'enterrondo' then
        conf['Target'] = 17101278
        conf['Target Index'] = 470
        working = true
        action = 710
        poke(conf)
    end

    if command[1] == 'elvorsealgoblinpoke' then
        conf['Target'] = 17969973
        conf['Target Index'] = 821
        working = true
        action = 2000
        poke(conf)
    end

    if command[1] == 'alzadaalexit' then
        conf['Target'] = 17072217
        conf['Target Index'] = 89
        working = true
        action = 1000
        poke(conf)
    end

    if command[1] == 'poketagnpc' then
        conf['Target'] = 16982171
        conf['Target Index'] = 155
        poke(conf)
    end

    if command[1] == 'portwg' then
        working = true
        action = 30
        conf['Target'] = 17101271
        conf['Target Index'] = 471
        poke(conf)
    end

    if command[1] == 'exitassault' then
        working = true
        action = 29
        conf['Target'] = 17060015
        conf['Target Index'] = 175
        poke(conf)
    end

    if command[1] == 'getarmband' then
        working = true
        action = 28
        conf['Target'] = 17101327
        conf['Target Index'] = 516
        poke(conf)
    end

    if command[1] == 'portsanctum' then
        working = true
        action = 27
        conf['Target'] = 16982076
        conf['Target Index'] = 60
        poke(conf)
    end

    if command[1] == 'gettag' then
        working = true
        action = 25
        conf['Target'] = 16982171
        conf['Target Index'] = 155
        poke(conf)
    end

    if command[1] == 'getorders' then
        working = true
        action = 26
        conf['Target'] = 16982174
        conf['Target Index'] = 158
        poke(conf)
    end

    if command[1] == 'engage' then
            local packet = packets.new('outgoing', 0x01A)
            packet["Target"] = tonumber(command[2])
            packet['Target Index'] = tonumber(command[3])
            packet["Category"] = 2
            packet["Param"] = 0
            packet["_unknown1"] = 0
            packet["X Offset"] = 0
            packet["Z Offset"] = 0
            packet["Y Offset"] = 0
            packets.inject(packet)
    end

    if command[1] == 'disengage' then
            local packet = packets.new('outgoing', 0x01A)
            packet["Target"] = tonumber(command[2])
            packet['Target Index'] = tonumber(command[3])
            packet["Category"] = 4
            packet["Param"] = 0
            packet["_unknown1"] = 0
            packet["X Offset"] = 0
            packet["Z Offset"] = 0
            packet["Y Offset"] = 0
            packets.inject(packet)
    end

    if command[1] == 'fixmenu' then
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17719635
            packet["Option Index"] = 2
            packet["_unknown1"] = 770
            packet['Target Index'] = 339
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 230
            packet["Menu ID"] = 963
            packets.inject(packet)
            windower.add_to_chat(2,"done")
    end

    if command[1] == 'popmorta' then
        working = true
        action = 100
        conf['Target'] = 17056471
        conf['Target Index'] = 727
        poke(conf)
    end

    if command[1] == 'buyrubi' then
        working = true
        action = 22
        conf['Target'] = 17719635
        conf['Target Index'] = 339
        poke(conf)
    end

    if command[1] == 'popchest2' then
        working = true
        action = 17
        conf['Target'] = 17310114
        conf['Target Index'] = 418
        poke(conf)
        coroutine.sleep(0.4)
        conf['Target'] = 17310114
        conf['Target Index'] = 418
        poke(conf)
    end

    if command[1] == 'popaello2' then
        working = true
        action = 15
        conf['Target'] = 17310111
        conf['Target Index'] = 415
        poke(conf)
    end

    if command[1] == 'endlamp' then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = 17076918
        packet["Option Index"] = 0
        packet["_unknown1"] = 0
        packet["Target Index"] = 694
        packet["Automated Message"] = false
        packet["_unknown2"] = 0
        packet["Zone"] = 73
        packet["Menu ID"] = 500
        packets.inject(packet)
    end

    if command[1] == 'pokelamp' then
        working = true
        action = 4
        conf['Target'] = 17076918
        conf['Target Index'] = 694
        poke(conf)
    end    

    if command[1]  == 'safepoke' then
        conf['Target'] = 17076918
        conf['Target Index'] = 694
        poke(conf)
    end

    if command[1]  == 'safepoke2' then
        conf['Target'] = command[2]
        conf['Target Index'] = command[3]
        windower.add_to_chat(0, ">> safepoke2 " .. command[2] .. " - " .. command[3])
        poke(conf)
        --coroutine.sleep(0.4)
        --conf['Target'] = command[2]
        --conf['Target Index'] = command[3]
        --poke(conf)
    end

    if command[1] == 'pokelamp2' then
        working = true
        action = 4
        conf['Target'] = command[2]
        conf['Target Index'] = command[3]
        windower.add_to_chat(0, ">> pokelamp2 " .. command[2] .. " - " .. command[3])
        poke(conf)
    end    

    if command[1] == 'unlock2'  then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = command[3]
        packet["Option Index"] = command[5]
        packet["_unknown1"] = 0
        packet["Target Index"] = command[4]
        packet["Automated Message"] = true
        packet["_unknown2"] = 0
        packet["Zone"] = command[2]
        packet["Menu ID"] = 500
        packets.inject(packet)
    end

    if command[1] == 'endlamp2' then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = command[3]
        packet["Option Index"] = 0
        packet["_unknown1"] = 0
        packet["Target Index"] = command[4]
        packet["Automated Message"] = false
        packet["_unknown2"] = 0
        packet["Zone"] = command[2]
        packet["Menu ID"] = 500
        packets.inject(packet)
    end
    
    if command[1] == 'unlock'  then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = 17076918
        packet["Option Index"] = command[2]
        packet["_unknown1"] = 0
        packet["Target Index"] = 694
        packet["Automated Message"] = true
        packet["_unknown2"] = 0
        packet["Zone"] = 73
        packet["Menu ID"] = 500
        packets.inject(packet)
    end

    if command[1]  == 'doorconfirm' then
        working = true
        action = 5
        conf['Target'] = command[2]
        conf['Target Index'] = command[3]
        conf['Menu ID'] = command[4]
        conf['Menu Index'] = command[5]
        poke(conf)
    end

    if command[1]  == 'doorconfirm2' then
        working = true
        action = 8
	conf['Zone'] = command[2]
        conf['Target'] = command[3]
        conf['Target Index'] = command[4]
        conf['Menu ID'] = command[5]
        conf['Menu Index'] = command[6]
        poke(conf)
    end

    if command[1] == 'pokerunicportal' then
        working = true
        action = -100
        conf['Target'] = 16982076
        conf['Target Index'] = 60
        poke(conf)
    end

    if command[1] == 'warptoalzadaal' then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = 16982076
        packet["Option Index"] = 6
        packet["_unknown1"] = 0
        packet['Target Index'] = 60
        packet["Automated Message"] = false
        packet["_unknown2"] = 0
        packet["Zone"] = 50
        packet["Menu ID"] = 101
        packets.inject(packet)
    end

    if command[1] == 'warptosanctum' then
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = 16982076
        packet["Option Index"] = 1
        packet["_unknown1"] = 0
        packet["Target Index"] = 60
        packet["Automated Message"] = false
        packet["_unknown2"] = 0
        packet["Zone"] = 50
        packet["Menu ID"] = 120
        packets.inject(packet)
    end

    if command[1] == 'warptonyzul' then
        working = true
        action = 6
        conf['Target'] = 16982076
        conf['Target Index'] = 60
        poke(conf)
    end
    if command[1] == 'door' then
        conf['Target'] = command[2]
        conf['Target Index'] = command[3]
        poke(conf)

    end
    if command[1] == 'permit' then
        working = true
        action = 2
        conf['Target'] = 16982309;
        conf['Target Index'] = 293;
        poke(conf)
    end
end)

windower.register_event('incoming chunk',function(id,data,modified,injected,blocked)

    if (id == 0x034 or id == 0x032) and working == true and action == -100 then -- fixing nyzul
        action = -1
        working = false
        return true
    end


   if id == 0x05C then
        local result2 = data:unpack('I', 0x21)
        --windower.add_to_chat(0, "result2: " .. result2)
   end


    if action == 4400 and working == true and id == 0x034 then
        local packet = packets.new('outgoing', 0x05B)
        packet['Target'] = 17908275
        packet['Option Index'] = 865
        packet['_unknown1'] = 0
        packet['Target Index'] = 563
        packet['Automated Message'] = true
        packet['_unknown2'] = 0
        packet['Zone'] = 276
        packet['Menu ID'] = 5517
        packets.inject(packet)   
        working = true
        action = 4401
        return true
    end

    if action == 4401 and working == true and id == 0x05C then
        local result = data:unpack('I', 0x21)
        --windower.add_to_chat(0, "result: " .. result)
        if result == 8 then
            coroutine.sleep(0.8)
            windower.add_to_chat(0, "=== Entering Sinister Reign: Ingrid")
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17908275
            packet['Option Index'] = 8
            packet['_unknown1'] = 0
            packet['Target Index'] = 563
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 276
            packet['Menu ID'] = 5517
            packets.inject(packet) 
            working = false
            action = -1  
        elseif result == 3 or result == 7 then
            windower.add_to_chat(0, "=== Failed, unknown reason..")
            working = false
            action = -1  
        elseif result == 9 then
            windower.add_to_chat(0, "=== Failed, and Retrying...")
            coroutine.sleep(5)
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17908275
            packet['Option Index'] = 865
            packet['_unknown1'] = 0
            packet['Target Index'] = 563
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 276
            packet['Menu ID'] = 5517
            packets.inject(packet)   
            working = true
            action = 4401
        else
            coroutine.sleep(0.8)
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17908275
            packet['Option Index'] = 4961
            packet['_unknown1'] = 0
            packet['Target Index'] = 563
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 276
            packet['Menu ID'] = 5517
            packets.inject(packet)   
        end
        return
    end

    -- Sinister Reign                           -- 0x037 = menu incoming
    -- Initial Malobra Poke Response, He's asking "What do you want?"
    if action == 4300 and working == true and id == 0x034 then
        local packet = packets.new('outgoing', 0x05B)
        -- This packet tells him, "I want to buy a moth"
        packet['Target'] = 17908273
        packet['Option Index'] = 1
        packet['_unknown1'] = 0
        packet['Target Index'] = 561
        packet['Automated Message'] = true
        packet['_unknown2'] = 0
        packet['Zone'] = 276
        packet['Menu ID'] = 3
        packets.inject(packet)   

        local packet2 = packets.new('outgoing', 0x05B)
        packet2['Target'] = 17908273
        packet2['Option Index'] = 2
        packet2['_unknown1'] = 0
        packet2['Target Index'] = 561
        packet2['Automated Message'] = true
        packet2['_unknown2'] = 0
        packet2['Zone'] = 276
        packet2['Menu ID'] = 3
        packets.inject(packet2) 

        local packet3 = packets.new('outgoing', 0x05B)
        packet3['Target'] = 17908273
        packet3['Option Index'] = 2
        packet3['_unknown1'] = 0
        packet3['Target Index'] = 561
        packet3['Automated Message'] = false
        packet3['_unknown2'] = 0
        packet3['Zone'] = 276
        packet3['Menu ID'] = 3
        packets.inject(packet3)  
        working = false
        action = -1
        return true
    end

    if action == 712 and working == true and id == 0x037 then
        local packet = packets.new('outgoing', 0x016)
        packet['Target Index'] = getid()
        packet['_junk1'] = 0            
        packets.inject(packet)
        working = false
        action = -1
    end

    if action == 711 and working == true and id == 0x0BF then
        local result = data:unpack('h', 0x06)
        --windower.add_to_chat(2, "packet: " .. result)
        --local p = packets.parse('incoming', data)
        if result == 1024 then
            local packet = packets.new('outgoing', 0x05B)
            windower.add_to_chat(2, '>> NPCHE BRS')
            packet['Target'] = 17101270
            packet['Option Index'] = 4
            packet['_unknown1'] = 0
            packet['Target Index'] = 470
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 79
            packet['Menu ID'] = 140
            packets.inject(packet)
            action = -1
            working = false    
        else
            windower.add_to_chat(2, '>> NPCHE BRF')
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17101270
            packet['Option Index'] = 6
            packet['_unknown1'] = 0
            packet['Target Index'] = 470
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 79
            packet['Menu ID'] = 140
            packets.inject(packet)
            
            action = 712
            working = true
        end
    end

    if id == 0x01D and working == true and action == 784 then
        local packet2 = packets.new('outgoing', 0x05B)
        packet2["Target"] = 17097342
        packet2["Option Index"] = 72
        packet2["_unknown1"] = 0
        packet2["Target Index"] = 638
        packet2["Automated Message"] = false
        packet2["_unknown2"] = 0
        packet2["Zone"] = 78
        packet2["Menu ID"] = 2
        packets.inject(packet2)
        working = false

    end
    if id == 0x034 and working == true and action == 783 then 
        local packet = packets.new('outgoing', 0x05B)
        packet["Target"] = 17097342
        packet["Option Index"] = 8
        packet["_unknown1"] = 0
        packet["Target Index"] = 638
        packet["Automated Message"] = true
        packet["_unknown2"] = 0
        packet["Zone"] = 78
        packet["Menu ID"] = 2
        action = 784
        working = true
        packets.inject(packet)
        return true
    end
    
    if action >= 2000 and action < 4300 and working == true then

        if action == 2007 and id == 0x052 then
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 12
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)   
            working = false
            action = -1                     
        end

        if action == 2006 and id == 0x052 then
            action = 2007            
            local packet = packets.new('outgoing', 0x05C)
            packet['X'] = 640
            packet['Z'] = -372.00003051758
            packet['Y'] = -921.00006103516
            packet['Target ID'] = 17969973
            packet['_unknown1'] = 12
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packet['Target Index'] = 821
            packet['_unknown3'] = 24321
            packets.inject(packet)
        end

        if action == 2005 and id == 0x052 then
            action = 2006
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 11
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

        if action == 2004 and id == 0x052 then
            action = 2005
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 10
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

        if action == 2003 and id == 0x052 then
            action = 2004
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 9
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

        if action == 2002 and id == 0x052 then
            action = 2003
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 9
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

        if action == 2001 and id == 0x052 then
            action = 2002
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 8
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

        if action == 2000 and id == 0x037 then
            action = 2001
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17969973
            packet['Option Index'] = 14
            packet['_unknown1'] = 0
            packet['Target Index'] = 821
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 291
            packet['Menu ID'] = 9701
            packets.inject(packet)            
        end

    end

    if (id == 0x052 and working == true) then
        if action == 1010 then
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17072217
            packet['Option Index'] = 0
            packet['_unknown1'] = 0
            packet['Target Index'] = 89
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 72
            packet['Menu ID'] = 115
            action = -1
            working = false
            packets.inject(packet)
        elseif action == 1005 then
            local packet = packets.new('outgoing', 0x05C)
            packet['X'] = 180.00001525879
            packet['Z'] = 0
            packet['Y'] = -43.581001281738
            packet['Target ID'] = 17072217
            packet['_unknown1'] = 0
            packet['Zone'] = 72
            packet['Menu ID'] = 115
            packet['Target Index'] = 89
            packet['_unknown3'] = 16129
            action = 1010
            packets.inject(packet)
        end

    end

    if (id == 0x067 and working == true) then
        if action == 1000 then
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17072217
            packet['Option Index'] = 0
            packet['_unknown1'] = 0
            packet['Target Index'] = 89
            packet['Automated Message'] = true
            packet['_unknown2'] = 0
            packet['Zone'] = 72
            packet['Menu ID'] = 115
            action = 1005
            packets.inject(packet)
        end
    end

    if (id == 0x032 or id == 0x034) and working == true then

        if action >= 2000 then
            return true
        end

        if action == 1000 then
            return true
        end

        rechest = false
        working = false

        if action == 710 then
            action = 711
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17101270
            packet["Option Index"] = 0
            packet["_unknown1"] = 4
            packet["Target Index"] = 470
            packet["Automated Message"] = true
            packet["_unknown2"] = 0
            packet["Zone"] = 79
            packet["Menu ID"] = 140
            packets.inject(packet)
 
            working = true
            return true
        end

        if action == 701 then
            working = false
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16875919
            packet["Option Index"] = 12
            packet["_unknown1"] = 0
            packet["Target Index"] = 399
            packet["Automated Message"] = true
            packet["_unknown2"] = 0
            packet["Zone"] = 24
            packet["Menu ID"] = 9002
            packets.inject(packet)

            local packet2 = packets.new('outgoing', 0x05B)
            packet2["Target"] = 16875919
            packet2["Option Index"] = 1
            packet2["_unknown1"] = 0
            packet2["Target Index"] = 399
            packet2["Automated Message"] = false
            packet2["_unknown2"] = 0
            packet2["Zone"] = 24
            packet2["Menu ID"] = 9002
            packets.inject(packet2)
            return true
        end


        if action == 702 then
            working = false
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17199757
            packet["Option Index"] = 12
            packet["_unknown1"] = 0
            packet["Target Index"] = 653
            packet["Automated Message"] = true
            packet["_unknown2"] = 0
            packet["Zone"] = 103
            packet["Menu ID"] = 9000
            packets.inject(packet)

            local packet2 = packets.new('outgoing', 0x05B)
            packet2["Target"] = 17199757
            packet2["Option Index"] = 1
            packet2["_unknown1"] = 0
            packet2["Target Index"] = 653
            packet2["Automated Message"] = false
            packet2["_unknown2"] = 0
            packet2["Zone"] = 103
            packet2["Menu ID"] = 9000
            packets.inject(packet2)
            return true
        end



        if action == 703 then
            working = false
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17199757
            packet["Option Index"] = 12
            packet["_unknown1"] = 0
            packet["Target Index"] = 653
            packet["Automated Message"] = true
            packet["_unknown2"] = 0
            packet["Zone"] = 103
            packet["Menu ID"] = 9000
            packets.inject(packet)

            local packet2 = packets.new('outgoing', 0x05B)
            packet2["Target"] = 17199757
            packet2["Option Index"] = 1
            packet2["_unknown1"] = 0
            packet2["Target Index"] = 653
            packet2["Automated Message"] = false
            packet2["_unknown2"] = 0
            packet2["Zone"] = 103
            packet2["Menu ID"] = 9000
            packets.inject(packet2)
            return true
        end



        if action == 666 then
            working = false
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17195618
            packet["Option Index"] = 2
            packet["_unknown1"] = 0
            packet["Target Index"] = 610
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 102
            packet["Menu ID"] = 222
            packets.inject(packet)
            return true
        end

        if action == 30 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17101271
            packet['Option Index'] = 1
            packet['_unknown1'] = 0
            packet['Target Index'] = 471
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 79
            packet['Menu ID'] = 131
            packets.inject(packet)
            return true
        end


        if action == 29 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17060015
            packet['Option Index'] = 1
            packet['_unknown1'] = 0
            packet['Target Index'] = 175
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 69
            packet['Menu ID'] = 100
            packets.inject(packet)
            return true
        end

        if action == 28 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet['Target'] = 17101316
            packet['Option Index'] = 1
            packet['_unknown1'] = 0
            packet['Target Index'] = 516
            packet['Automated Message'] = false
            packet['_unknown2'] = 0
            packet['Zone'] = 79
            packet['Menu ID'] = 149
            packets.inject(packet)
            return true
        end

        if action == 27 then --do the autoport to leujoam sanctum
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982076
            packet["Option Index"] = 1
            packet["_unknown1"] = 0
            packet["Target Index"] = 60
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 120
            packets.inject(packet)
            return true
        end

        if action == 26 then --get bloody rondo orders
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982174
            packet["Option Index"] = 161
            packet["_unknown1"] = 0
            packet["Target Index"] = 158
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 273
            packets.inject(packet)
            return true
        end

        if action == 25 then -- get assault tag
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982171
            packet["Option Index"] = 1
            packet["_unknown1"] = 0
            packet["Target Index"] = 155
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 268
            packets.inject(packet)
            return true
        end
        if action == 100 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17056471
            packet["Option Index"] = 81 --49
            packet["_unknown1"] = 0
            packet['Target Index'] = 727
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 68
            packet["Menu ID"] = 6001
            packets.inject(packet)
            return true
        end
        if action == 22 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17719635
            packet["Option Index"] = 2
            packet["_unknown1"] = 770
            packet['Target Index'] = 339
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 230
            packet["Menu ID"] = 963
            packets.inject(packet)
            return true
        end
        if action == 17 then
            local pkp = packets.parse('incoming', data)
            windower.add_to_chat(2, "menu id: " .. pkp["Menu ID"] .. "   _unk1: " .. pkp["_unknown1"])
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17310114
            packet["Option Index"] = 10
            packet["_unknown1"] = 0
            packet['Target Index'] = 418
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 130
            packet["Menu ID"] = 6003
            packets.inject(packet)
            return true
        end
        if action == 15 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 17310111
            packet["Option Index"] = 49
            packet["_unknown1"] = 0
            packet['Target Index'] = 415
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 130
            packet["Menu ID"] = 6000
            packets.inject(packet)
            return true
        end
        if action == 6 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982076
            packet["Option Index"] = 6
            packet["_unknown1"] = 0
            packet['Target Index'] = 60
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 101
            packets.inject(packet)
            return true
        end
        if action == 5 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = conf['Target']
            packet["Option Index"] = conf['Menu Index']
            packet["_unknown1"] = 0
            packet["Target Index"] = conf['Target Index']
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 73
            packet["Menu ID"] = conf['Menu ID']
            packets.inject(packet)
            return true
        end
        if action == 8 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = conf['Target']
            packet["Option Index"] = conf['Menu Index']
            packet["_unknown1"] = 0
            packet["Target Index"] = conf['Target Index']
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = conf['Zone']
            packet["Menu ID"] = conf['Menu ID']
            packets.inject(packet)
            return true
        end
	if action == 4 then
            windower.add_to_chat(2, ">> NPCHE LAMP OK")
            action = -1
            return true
        end
        if action == 1 then
            action = -1
            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982457
            packet["Option Index"] = 0
            packet["_unknown1"] = 0
            packet["Target Index"] = 441
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 630
            packets.inject(packet)
            return true
        end
        if action == 2 then
            action = -1
            local packet3 = packets.new('outgoing', 0x05B)
            packet3["Target"] = 16982309
            packet3["Option Index"] = 0
            packet3["_unknown1"] = 0
            packet3["Target Index"] = 293
            packet3["Automated Message"] = true
            packet3["_unknown2"] = 0
            packet3["Zone"] = 50
            packet3["Menu ID"] = 820
            packets.inject(packet3)

            local packet2 = packets.new('outgoing', 0x05B)
            packet2["Target"] = 16982309
            packet2["Option Index"] = 10
            packet2["_unknown1"] = 0
            packet2["Target Index"] = 293
            packet2["Automated Message"] = true
            packet2["_unknown2"] = 0
            packet2["Zone"] = 50
            packet2["Menu ID"] = 820
            packets.inject(packet2)

            local packet = packets.new('outgoing', 0x05B)
            packet["Target"] = 16982309
            packet["Option Index"] = 100
            packet["_unknown1"] = 0
            packet["Target Index"] = 293
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = 50
            packet["Menu ID"] = 820
            packets.inject(packet)
            return true
        end
    end
end)

function getid() 
    for i,v in pairs(windower.ffxi.get_mob_array()) do
        if v['name'] == windower.ffxi.get_player().name then
            --windower.add_to_chat(2, "Player Index: " .. i)
            return i
        end
    end
end


function poke(c)
    local packet = packets.new('outgoing', 0x01A, {
        ["Target"] = c['Target'],
        ["Target Index"] = c['Target Index'],
        ["Category"] = 0,
        ["Param"] = 0,
        ["_unknown1"] = 0})
        --windower.add_to_chat(2,">>> Poking with Packets! ("..c['Target']..")")
        packets.inject(packet)
end